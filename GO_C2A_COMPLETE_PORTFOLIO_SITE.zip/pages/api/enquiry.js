
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const { name, location, phone, material, priority } = req.body;

  // 1. Send to Google Sheets (via Sheet.best or custom webhook)
  await fetch('https://sheet.best/api/sheets/YOUR_SHEET_ID', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, location, phone, material, priority })
  });

  // 2. Send Email (EmailJS or Nodemailer setup needed here)

  // 3. Send WhatsApp message (via Twilio or webhook)
  // Example: await fetch('https://your-whatsapp-webhook', {...})

  return res.status(200).json({ message: "Enquiry submitted successfully!" });
}
