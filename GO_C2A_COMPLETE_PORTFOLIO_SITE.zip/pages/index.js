
import Head from 'next/head';
import HeroSection from '../components/HeroSection';
import ProductGrid from '../components/ProductGrid';
import EnquiryForm from '../components/EnquiryForm';
import Footer from '../components/Footer';

export default function Home() {
  return (
    <>
      <Head>
        <title>GO C2A SHOP | Construction Supplies</title>
      </Head>
      <main className="bg-gray-50 text-gray-900">
        <HeroSection />
        <ProductGrid />
        <EnquiryForm />
        <Footer />
      </main>
    </>
  );
}
