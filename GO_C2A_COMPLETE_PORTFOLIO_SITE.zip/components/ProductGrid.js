
const products = [
  {
    name: "Wall & Floor Tiles",
    image: "/images/products/tiles.jpg",
    brands: ["G.C CERA", "SPARROW", "ANUJ", "KAG", "RSM", "RT"]
  },
  {
    name: "Electricals & LED",
    image: "/images/products/electrical.jpg",
    brands: ["HAVELLS", "REO", "LEGRAND", "HELLO", "NORWOOD"]
  },
  {
    name: "Plumbing & Sanitary",
    image: "/images/products/plumbing.jpg",
    brands: ["AGL", "PARAS", "CARRYON", "PARRYWARE", "AQUAGOLD"]
  },
  {
    name: "SS Railings",
    image: "/images/products/railing.jpg",
    brands: ["JINDAL", "JSLA", "JSW"]
  },
  {
    name: "Interiors & Modular Kitchen",
    image: "/images/products/interior.jpg",
    brands: ["ACTION TESSA", "GREENLAM", "MERINOLAM"]
  },
  {
    name: "Customizable Doors",
    image: "/images/products/doors.jpg",
    brands: ["PENTO PLASTECH", "EROLINE"]
  },
  {
    name: "UPVC Windows & Doors",
    image: "/images/products/windows.jpg",
    brands: ["-"]
  },
  {
    name: "Kitchen Accessories",
    image: "/images/products/kitchen.jpg",
    brands: ["HABLO", "RAZER", "YALE", "JOLLY"]
  },
  {
    name: "Ceiling Solutions",
    image: "/images/products/ceiling.jpg",
    brands: ["GYPROC", "USG BORAL", "VOX", "KUNAL"]
  }
];

export default function ProductGrid() {
  return (
    <section className="py-10 bg-white">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-3xl font-bold mb-6 text-center">Our Products</h2>
        <div className="grid gap-6 sm:grid-cols-2 md:grid-cols-3">
          {products.map((product, index) => (
            <div key={index} className="bg-gray-50 border rounded shadow hover:shadow-lg transition">
              <img src={product.image} alt={product.name} className="w-full h-48 object-cover rounded-t" />
              <div className="p-4">
                <h3 className="text-xl font-semibold">{product.name}</h3>
                <p className="text-sm text-gray-600">Brands: {product.brands.join(", ")}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
