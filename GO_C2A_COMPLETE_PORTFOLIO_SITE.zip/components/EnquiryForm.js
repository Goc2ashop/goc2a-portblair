
import { useState } from 'react';

export default function EnquiryForm() {
  const [formData, setFormData] = useState({
    name: '',
    location: '',
    phone: '',
    material: '',
    priority: 'in month'
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await fetch('/api/enquiry', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    });
    const data = await res.json();
    alert(data.message || "Enquiry submitted!");
  };

  return (
    <div className="p-6 bg-white rounded shadow max-w-xl mx-auto my-10">
      <h2 className="text-2xl font-bold mb-4">Submit Your Enquiry</h2>
      <form onSubmit={handleSubmit} className="grid gap-4">
        <input className="border p-2" type="text" placeholder="Name" onChange={e => setFormData({ ...formData, name: e.target.value })} required />
        <input className="border p-2" type="text" placeholder="Location" onChange={e => setFormData({ ...formData, location: e.target.value })} required />
        <input className="border p-2" type="tel" placeholder="Mobile Number" onChange={e => setFormData({ ...formData, phone: e.target.value })} required />
        <input className="border p-2" type="text" placeholder="Material Needed" onChange={e => setFormData({ ...formData, material: e.target.value })} required />
        <select className="border p-2" onChange={e => setFormData({ ...formData, priority: e.target.value })}>
          <option value="in month">In a month</option>
          <option value="in 3 months">In 3 months</option>
          <option value="more than 3 months">More than 3 months</option>
        </select>
        <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">Submit Enquiry</button>
      </form>
    </div>
  );
}
